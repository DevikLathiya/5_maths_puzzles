import 'package:flutter/material.dart';
import 'package:math_puzzles/Config.dart';
import 'package:math_puzzles/Dashbord.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LevelPage extends StatefulWidget {
  const LevelPage({Key? key}) : super(key: key);

  @override
  State<LevelPage> createState() => _LevelPageState();
}

class _LevelPageState extends State<LevelPage> {
  SharedPreferences ? pref ;
  share_pref() async {
    pref = await SharedPreferences.getInstance();
    cur_level = pref!.getInt("levelno") ?? 0 ;

    for(int i=0;i<cur_level;i++)
    {
      String str = pref!.getString("Lstatus$i") ?? "no";
      lock[i]=str;
    }
    setState(() {
    });
  }

  @override
  void initState() {
    super.initState();
    share_pref();
    print(lock);
    lock=List.filled(level_img.length, "");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(height: double.infinity,width: double.infinity,
         decoration: BoxDecoration(image: DecorationImage(fit: BoxFit.fill,image: AssetImage("image/background.jpg"))),
        child:Column(
          children: [
            Expanded(
              child: Container(height: double.infinity,width: double.infinity,alignment: Alignment.center,
                child:Text("Select Puzzle",style: TextStyle(fontSize: 35,fontWeight: FontWeight.bold),),
              ),
            ),
              Expanded(
                flex: 5,
                child: GridView.builder(
                  itemCount: level_img.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 4),
                  itemBuilder: (context, index) {
                    return InkWell(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) {
                          return Dashbord();
                        },));
                      },
                      child: Container(
                          margin: EdgeInsets.all(5),
                          alignment: Alignment.center,
                          child: (index < cur_level) ? Text("${levels[index]}") : null,
                          decoration: BoxDecoration(
                              border: (index < cur_level) ?Border.all(color: Colors.black) : null,
                              borderRadius: BorderRadius.circular(10),
                              image: (index < cur_level)
                                      ? (lock[index]=="win")
                                      ? DecorationImage(image: AssetImage("image/tick.png"))
                                       : null
                                     : DecorationImage(image: AssetImage("image/lock.png"))
                          )),
                    );
                  },
                ),
              ),
              Expanded(flex: 0,
              child: IconButton(onPressed: () {
                print("next");
              }, icon: Image(image: AssetImage("image/next.png"),)),
            )
          ],
        )
      ),
    );
  }
}
